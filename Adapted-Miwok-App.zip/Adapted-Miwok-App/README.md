# Adapted-Miwok-App
I Updated the Miwok app from the Android Development Udacity course to meet Android studio 2021. No more frustrations! Enjoy 🙂 and happy coding 👍
